package com.example.myapplication.model;

public class items {

    public String name;
    public String url;
    public Double currentValue;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Double getCurrentValue(){
        return currentValue;
    }

    public void setCurrentValue(Double currentValue){
        this.currentValue = currentValue;
    }

}
